import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { CategoryPage } from './pages/CategoryPage';
import { BookDetailsPage } from './pages/BookDetailsPage';
import { CategoriesPage } from './pages/CategoriesPage';
import { AboutPage } from './pages/AboutPage';
import { BlogPage } from './pages/BlogPage';
import { ArticlePage } from './pages/ArticlePage';
import { FAQPage } from './pages/FAQPage';
import { LearnMorePage } from './pages/LearnMorePage';
import { SignUpPage } from './pages/SignUpPage';
import { BrowseBooksPage } from './pages/BrowseBooksPage';
import { ReadingGroupsPage } from './pages/ReadingGroupsPage';
import { ReadingChallengesPage } from './pages/ReadingChallengesPage';
import { ReadingAnalyticsPage } from './pages/ReadingAnalyticsPage';
import { AchievementsPage } from './pages/AchievementsPage';
import { FavoriteBooksPage } from './pages/FavoriteBooksPage';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/category/:categoryName" element={<CategoryPage />} />
        <Route path="/book/:bookId" element={<BookDetailsPage />} />
        <Route path="/categories" element={<CategoriesPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/blog/article/:articleId" element={<ArticlePage />} />
        <Route path="/faq" element={<FAQPage />} />
        <Route path="/learn-more" element={<LearnMorePage />} />
        <Route path="/signup" element={<SignUpPage />} />
        <Route path="/browse-books" element={<BrowseBooksPage />} />
        <Route path="/reading-groups" element={<ReadingGroupsPage />} />
        <Route path="/reading-challenges" element={<ReadingChallengesPage />} />
        <Route path="/reading-analytics" element={<ReadingAnalyticsPage />} />
        <Route path="/achievements" element={<AchievementsPage />} />
        <Route path="/favorites" element={<FavoriteBooksPage />} />
      </Routes>
      <Footer />
    </div>
  );
}