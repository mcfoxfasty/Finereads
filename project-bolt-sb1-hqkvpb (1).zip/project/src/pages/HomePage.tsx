import React, { useState, useEffect } from 'react';
import { Hero } from '../components/Hero';
import { Stats } from '../components/Stats';
import { BookSection } from '../components/BookSection';
import { CategorySection } from '../components/CategorySection';
import { CategoryBrowser } from '../components/CategoryBrowser';
import { ArticleSection } from '../components/ArticleSection';
import { PromotionBanner } from '../components/PromotionBanner';
import { BestSellersSection } from '../components/BestSellersSection';
import { searchBooksByCategory, getEditorsPicks } from '../services/books';
import { Book } from '../types/book';

export function HomePage() {
  const [popularBooks, setPopularBooks] = useState<Book[]>([]);
  const [editorsPicks, setEditorsPicks] = useState<Book[]>([]);

  useEffect(() => {
    const loadBooks = async () => {
      try {
        // Load editor's picks
        const picks = await getEditorsPicks();
        setEditorsPicks(picks);

        // Load popular books
        const popular = await searchBooksByCategory('fiction', 10, 'relevance');
        setPopularBooks(popular);
      } catch (error) {
        console.error('Error loading books:', error);
      }
    };

    loadBooks();
  }, []);

  return (
    <main>
      <Hero />
      <Stats />
      <CategoryBrowser />
      <BestSellersSection />
      <BookSection title="Editor's Picks" books={editorsPicks} viewAllLink="/editors-picks" />
      <CategorySection category="Mystery" viewAllLink="/category/mystery" />
      <CategorySection category="Romance" viewAllLink="/category/romance" />
      <CategorySection category="Science Fiction" viewAllLink="/category/science-fiction" />
      <BookSection title="Popular Books" books={popularBooks} viewAllLink="/popular" />
      <PromotionBanner />
      <ArticleSection />
    </main>
  );
}