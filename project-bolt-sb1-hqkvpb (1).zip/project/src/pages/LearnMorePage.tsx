import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Users, Star, BookMarked, Library, Sparkles, BookCheck, Trophy } from 'lucide-react';

const features = [
  {
    icon: BookOpen,
    title: 'Track Your Reading Journey',
    description: 'Keep track of books you\'ve read, are currently reading, and want to read. Set reading goals and monitor your progress.',
    link: '/reading-analytics'
  },
  {
    icon: Users,
    title: 'Join Reading Groups',
    description: 'Connect with fellow readers, join book clubs, and participate in engaging discussions about your favorite books.',
    link: '/reading-groups'
  },
  {
    icon: Star,
    title: 'Personalized Recommendations',
    description: 'Get book recommendations tailored to your reading preferences, history, and favorite genres.',
    link: '/browse-books'
  },
  {
    icon: BookMarked,
    title: 'Create Custom Collections',
    description: 'Organize your books into custom collections, whether by genre, theme, or your own unique categories.',
    link: '/browse-books'
  },
  {
    icon: Library,
    title: 'Virtual Bookshelf',
    description: 'Build and showcase your digital library. Share your collections and discover what others are reading.',
    link: '/browse-books'
  },
  {
    icon: Sparkles,
    title: 'Reading Challenges',
    description: 'Participate in reading challenges to discover new genres and authors while earning achievements.',
    link: '/reading-challenges'
  },
  {
    icon: BookCheck,
    title: 'Reading Analytics',
    description: 'Get insights into your reading habits with detailed statistics and progress tracking.',
    link: '/reading-analytics'
  },
  {
    icon: Trophy,
    title: 'Achievement System',
    description: 'Earn badges and rewards as you reach reading milestones and complete challenges.',
    link: '/achievements'
  }
];

export function LearnMorePage() {
  return (
    <main className="bg-white">
      {/* Hero Section */}
      <section className="relative bg-navy py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl">
              Elevate Your Reading Experience
            </h1>
            <p className="mt-6 max-w-2xl mx-auto text-xl text-gray-300">
              Discover a new way to explore, track, and share your reading journey with our comprehensive platform.
            </p>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-navy">
              Everything You Need to Enhance Your Reading Journey
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              Our platform offers a comprehensive set of features designed to make your reading experience more engaging and rewarding.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature) => (
              <Link
                key={feature.title}
                to={feature.link}
                className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-gray-100 group"
              >
                <feature.icon className="h-8 w-8 text-emerald-600 mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-xl font-bold text-navy mb-2 group-hover:text-emerald-600 transition-colors">
                  {feature.title}
                </h3>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-emerald-50 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-navy mb-6">
              Ready to Start Your Reading Journey?
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Join our community of readers and discover your next favorite book.
            </p>
            <div className="flex justify-center gap-4">
              <Link
                to="/signup"
                className="px-8 py-3 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
              >
                Sign Up Now
              </Link>
              <Link
                to="/browse-books"
                className="px-8 py-3 border border-emerald-600 text-emerald-600 rounded-lg hover:bg-emerald-50 transition-colors"
              >
                Browse Books
              </Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}