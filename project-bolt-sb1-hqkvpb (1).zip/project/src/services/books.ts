import { Book, BookDetails } from '../types/book';
import { sampleBooks, editorsPickBooks, sampleBookDetails } from '../data/books';
import { getNextApiKey } from './apiKeys';
import { getCachedData, setCachedData } from './cache';

const BASE_URL = 'https://www.googleapis.com/books/v1/volumes';

const handleApiError = (error: unknown, fallbackData: any) => {
  const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
  console.warn(`Using fallback data. ${errorMessage}`);
  return fallbackData;
};

const validateApiResponse = async (response: Response) => {
  if (!response.ok) {
    throw new Error(`API request failed with status ${response.status}`);
  }
  const data = await response.json();
  if (!data) {
    throw new Error('No data received from API');
  }
  return data;
};

const determineBookCondition = (saleInfo: any): boolean => {
  if (saleInfo?.saleability === 'FOR_SALE' && saleInfo?.isEbook) {
    return false;
  }
  return Math.random() < 0.3;
};

const mapBookData = (item: any): Book => {
  const isUsed = determineBookCondition(item.saleInfo);
  const price = item.saleInfo?.listPrice?.amount || 
                (isUsed ? (Math.random() * 20 + 5).toFixed(2) : (Math.random() * 30 + 15).toFixed(2));

  return {
    id: item.id,
    title: item.volumeInfo?.title || 'Untitled',
    author: item.volumeInfo?.authors?.[0] || 'Unknown Author',
    description: item.volumeInfo?.description || 'No description available',
    coverUrl: item.volumeInfo?.imageLinks?.thumbnail?.replace('http:', 'https:') || 'https://via.placeholder.com/128x192?text=No+Cover',
    rating: item.volumeInfo?.averageRating || Math.floor(Math.random() * 2) + 3,
    reviewCount: item.volumeInfo?.ratingsCount || Math.floor(Math.random() * 1000),
    price: parseFloat(price),
    categories: item.volumeInfo?.categories || [],
    publishedDate: item.volumeInfo?.publishedDate || new Date().toISOString(),
    isUsed: isUsed,
    reviews: [],
    condition: isUsed ? 'Good' : 'New',
    format: item.saleInfo?.isEbook ? 'Ebook' : 'Paperback',
    downloadLink: item.accessInfo?.epub?.downloadLink || item.accessInfo?.pdf?.downloadLink,
    previewLink: item.volumeInfo?.previewLink,
    amazonLink: item.saleInfo?.buyLink
  };
};

async function fetchWithCache<T>(cacheKey: string, fetcher: () => Promise<T>, fallbackData: T): Promise<T> {
  const cachedData = getCachedData<T>(cacheKey);
  if (cachedData) return cachedData;

  try {
    const data = await fetcher();
    setCachedData(cacheKey, data);
    return data;
  } catch (error) {
    return handleApiError(error, fallbackData);
  }
}

export async function searchBooksByCategory(
  category: string,
  maxResults: number = 10,
  orderBy: 'relevance' | 'newest' = 'relevance'
): Promise<Book[]> {
  const cacheKey = `category-${category}-${maxResults}-${orderBy}`;
  
  return fetchWithCache(cacheKey, async () => {
    const response = await fetch(
      `${BASE_URL}?q=subject:${encodeURIComponent(category)}&maxResults=${maxResults}&orderBy=${orderBy}&key=${getNextApiKey()}`
    );
    
    const data = await validateApiResponse(response);
    return data.items?.map(mapBookData) || [];
  }, sampleBooks);
}

export async function getBookDetails(bookId: string): Promise<BookDetails> {
  const cacheKey = `book-details-${bookId}`;
  
  return fetchWithCache(cacheKey, async () => {
    const response = await fetch(`${BASE_URL}/${bookId}?key=${getNextApiKey()}`);
    const item = await validateApiResponse(response);
    
    const isUsed = determineBookCondition(item.saleInfo);
    const price = item.saleInfo?.listPrice?.amount || 
                 (isUsed ? (Math.random() * 20 + 5).toFixed(2) : (Math.random() * 30 + 15).toFixed(2));

    return {
      id: item.id,
      title: item.volumeInfo?.title || 'Untitled',
      subtitle: item.volumeInfo?.subtitle || '',
      authors: item.volumeInfo?.authors || ['Unknown Author'],
      description: item.volumeInfo?.description || 'No description available',
      coverUrl: item.volumeInfo?.imageLinks?.thumbnail?.replace('http:', 'https:') || 'https://via.placeholder.com/128x192?text=No+Cover',
      rating: item.volumeInfo?.averageRating || Math.floor(Math.random() * 2) + 3,
      ratingsCount: item.volumeInfo?.ratingsCount || Math.floor(Math.random() * 1000),
      reviewCount: item.volumeInfo?.ratingsCount || Math.floor(Math.random() * 1000),
      price: parseFloat(price),
      categories: item.volumeInfo?.categories || [],
      pageCount: item.volumeInfo?.pageCount || 0,
      publisher: item.volumeInfo?.publisher || 'Unknown Publisher',
      publishedDate: item.volumeInfo?.publishedDate || '',
      isbn: item.volumeInfo?.industryIdentifiers?.[0]?.identifier || '',
      language: item.volumeInfo?.language || 'en',
      isUsed: isUsed,
      reviews: [],
      condition: isUsed ? 'Good' : 'New',
      format: item.saleInfo?.isEbook ? 'Ebook' : 'Paperback',
      downloadLink: item.accessInfo?.epub?.downloadLink || item.accessInfo?.pdf?.downloadLink,
      previewLink: item.volumeInfo?.previewLink,
      amazonLink: item.saleInfo?.buyLink
    };
  }, sampleBookDetails);
}

export async function getBestSellers(): Promise<Book[]> {
  const cacheKey = 'best-sellers';
  
  return fetchWithCache(cacheKey, async () => {
    const bestSellerTitles = [
      'The Answer Is No: A Short Story',
      'The Boyfriend',
      'Lights Out: An Into Darkness Novel',
      'From Here to Eternity',
      'Forever Wild',
      'Meet Me at Midnight',
      'This Inevitable Ruin: Dungeon Crawler Carl Book 7',
      'My Rules',
      'The Wingman',
      'War',
      'The Bonus',
      'Just Between Us',
      'Dark Seduction',
      'A Curse of Fate',
      "It's Just Business",
      'Dear Rosie',
      'Voiceless Child',
      'How To: $10M'
    ];

    const booksPromises = bestSellerTitles.map(async (title) => {
      const query = encodeURIComponent(`intitle:"${title}"`);
      const response = await fetch(
        `${BASE_URL}?q=${query}&maxResults=1&key=${getNextApiKey()}`
      );
      const data = await validateApiResponse(response);
      return data.items?.[0] ? mapBookData(data.items[0]) : null;
    });

    const books = await Promise.all(booksPromises);
    return books.filter((book): book is Book => book !== null);
  }, sampleBooks);
}