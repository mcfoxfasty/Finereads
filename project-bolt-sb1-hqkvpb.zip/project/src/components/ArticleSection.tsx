import React from 'react';
import { Link } from 'react-router-dom';

const articles = [
  {
    id: 1,
    title: "The Art of Reading: Finding Your Perfect Book",
    excerpt: "Discover how to choose books that resonate with your interests and reading style.",
    image: "https://images.unsplash.com/photo-1474932430478-367dbb6832c1?auto=format&fit=crop&q=80&w=800",
    date: "2024-03-15"
  },
  {
    id: 2,
    title: "Why Used Books Have More Character",
    excerpt: "Explore the unique charm and stories hidden within pre-loved books.",
    image: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&q=80&w=800",
    date: "2024-03-10"
  },
  {
    id: 3,
    title: "Creating Your Perfect Reading Nook",
    excerpt: "Tips and ideas for designing a cozy space dedicated to your reading adventures.",
    image: "https://images.unsplash.com/photo-1519682577862-22b62b24e493?auto=format&fit=crop&q=80&w=800",
    date: "2024-03-05"
  }
];

export function ArticleSection() {
  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold text-navy">Latest Articles</h2>
          <Link to="/blog" className="text-emerald-600 hover:text-emerald-700">
            VIEW ALL →
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {articles.map((article) => (
            <div key={article.id} className="bg-white rounded-lg overflow-hidden shadow-md group">
              <div className="aspect-[16/9] overflow-hidden">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-2xl font-bold">
                    {new Date(article.date).getDate()}
                  </span>
                  <span className="text-emerald-600">
                    {new Date(article.date).toLocaleString('default', { month: 'short' })}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-navy mb-2 group-hover:text-emerald-600 transition-colors">
                  {article.title}
                </h3>
                <p className="text-gray-600 mb-4">
                  {article.excerpt}
                </p>
                <Link 
                  to={`/blog/${article.id}`} 
                  className="text-emerald-600 hover:text-emerald-700 inline-flex items-center"
                >
                  READ MORE →
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}