import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search } from 'lucide-react';

const categories = [
  ['Art', 'Comics', 'Historical Fiction', 'Nonfiction', 'Self Help'],
  ['Biography', 'Cookbooks', 'History', 'Poetry', 'Sports'],
  ['Business', 'Ebooks', 'Horror', 'Psychology', 'Thriller'],
  ["Children's", 'Fantasy', 'Memoir', 'Romance', 'Travel'],
  ['Christian', 'Fiction', 'Music', 'Science', 'Young Adult'],
  ['Classics', 'Graphic Novels', 'Mystery', 'Science Fiction', 'More genres']
];

export function CategoryBrowser() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  return (
    <section className="bg-navy text-white py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">
              <span className="text-white">Browse</span>{' '}
              <span className="text-gray-400">Books</span>
            </h2>
            <div className="relative w-64">
              <input
                type="search"
                placeholder="Search By Title, Author Or ISBN"
                className="w-full pl-10 pr-4 py-2 rounded-full text-gray-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-6 gap-4">
            {categories.map((column, colIndex) => (
              <div key={colIndex} className="space-y-4">
                {column.map((category) => (
                  <Link
                    key={category}
                    to={`/category/${category.toLowerCase().replace(/['\s]/g, '-')}`}
                    className={`block transition-colors ${
                      category === selectedCategory
                        ? 'bg-white text-navy rounded-full px-4 py-1'
                        : 'hover:text-emerald-400'
                    }`}
                    onClick={() => setSelectedCategory(category)}
                  >
                    {category}
                  </Link>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}