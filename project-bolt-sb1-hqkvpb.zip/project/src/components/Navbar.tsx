import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Menu, X, Heart, User, BookMarked, Library } from 'lucide-react';

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const menuItems = [
    { label: 'Home', href: '/' },
    { label: 'My Collection', href: '/collection' },
    { label: 'Reading List', href: '/reading-list' },
    { label: 'Rare Finds', href: '/rare-finds' },
    { label: 'Community', href: '/community' },
  ];

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto">
        {/* Top bar */}
        <div className="bg-navy text-white text-sm py-2 px-4 text-center">
          <p>Track your reading progress and discover rare editions</p>
        </div>

        {/* Main header */}
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-emerald-600" />
              <h1 className="text-2xl font-bold text-emerald-600">FineReads</h1>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              {menuItems.map((item) => (
                <Link
                  key={item.label}
                  to={item.href}
                  className="text-gray-600 hover:text-emerald-600 font-medium"
                >
                  {item.label}
                </Link>
              ))}
            </nav>

            {/* Icons */}
            <div className="flex items-center space-x-4">
              <Link to="/reading-list" className="p-2 text-gray-600 hover:text-emerald-600">
                <BookMarked className="h-6 w-6" />
              </Link>
              <Link to="/collection" className="p-2 text-gray-600 hover:text-emerald-600">
                <Library className="h-6 w-6" />
              </Link>
              <Link to="/wishlist" className="p-2 text-gray-600 hover:text-emerald-600">
                <Heart className="h-6 w-6" />
              </Link>
              <Link to="/profile" className="p-2 text-gray-600 hover:text-emerald-600">
                <User className="h-6 w-6" />
              </Link>
              <button
                className="md:hidden p-2 text-gray-600"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <nav className="px-4 py-2">
              {menuItems.map((item) => (
                <Link
                  key={item.label}
                  to={item.href}
                  className="block py-2 text-gray-600 hover:text-emerald-600 font-medium"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}