import React from 'react';

export function PromotionBanner() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-pink-100 rounded-lg p-8">
        <h3 className="text-2xl font-bold text-navy mb-4">Give the gift of a book!</h3>
        <button className="bg-red-500 text-white px-6 py-2 rounded-lg hover:bg-red-600">
          SEND AS GIFT
        </button>
      </div>
      <div className="bg-navy rounded-lg p-8 text-white">
        <h3 className="text-2xl font-bold mb-4">SANTA'S LITTLE HELPERS</h3>
        <div className="flex justify-between items-center">
          <p className="text-xl">25% OFF ON ENTIRE STORE</p>
          <button className="bg-emerald-500 text-white px-6 py-2 rounded-lg hover:bg-emerald-600">
            EXPLORER
          </button>
        </div>
      </div>
    </div>
  );
}