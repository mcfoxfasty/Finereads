import React from 'react';
import { Book, DollarSign, Star } from 'lucide-react';

export function Stats() {
  return (
    <div className="bg-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-3">
          <div className="flex items-center space-x-4">
            <Book className="h-8 w-8 text-emerald-500" />
            <div>
              <p className="text-2xl font-bold text-navy">56M</p>
              <p className="text-gray-600">Used Books Sold</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <DollarSign className="h-8 w-8 text-emerald-500" />
            <div>
              <p className="text-2xl font-bold text-navy">1.2B</p>
              <p className="text-gray-600">Customer Savings</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Star className="h-8 w-8 text-emerald-500" />
            <div>
              <p className="text-2xl font-bold text-navy">1.0M+</p>
              <p className="text-gray-600">5 Star Ratings</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}