import { Book } from '../types/book';

export const editorsPickBooks: Book[] = [
  {
    id: '1',
    title: 'Buddha Boy',
    author: 'Ron Chernow',
    price: 24.99,
    coverUrl: 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?auto=format&fit=crop&q=80&w=800',
    rating: 5,
    reviewCount: 128,
    reviews: [],
    categories: ['Fiction'],
    publishedDate: '2023-01-15',
    description: 'A compelling story of self-discovery...',
    isUsed: true
  },
  {
    id: '2',
    title: 'Skull Island',
    author: 'Ron Chernow',
    price: 19.99,
    coverUrl: 'https://images.unsplash.com/photo-1532012197267-da84d127e765?auto=format&fit=crop&q=80&w=800',
    rating: 5,
    reviewCount: 89,
    reviews: [],
    categories: ['Adventure'],
    publishedDate: '2023-02-20',
    description: 'An thrilling adventure...',
    isUsed: true
  },
  {
    id: '3',
    title: 'Poor Child',
    author: 'Ron Chernow',
    price: 22.99,
    coverUrl: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=800',
    rating: 5,
    reviewCount: 156,
    reviews: [],
    categories: ['Drama'],
    publishedDate: '2023-03-10',
    description: 'A touching story...',
    isUsed: true
  }
];

// Popular books will be fetched dynamically from Google Books API