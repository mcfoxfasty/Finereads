import React from 'react';
import { Calendar, User, ArrowRight } from 'lucide-react';

const featuredPost = {
  title: 'The Future of Reading: Digital vs Physical Books',
  excerpt: 'As technology advances, the debate between digital and physical books continues to evolve. We explore the pros and cons of each format and what it means for the future of reading.',
  image: 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?auto=format&fit=crop&q=80&w=1200',
  author: 'Sarah Johnson',
  date: '2024-03-15',
  category: 'Reading Trends',
};

const posts = [
  {
    title: '10 Classic Novels Everyone Should Read',
    excerpt: 'From Pride and Prejudice to 1984, these timeless works continue to captivate readers generation after generation.',
    image: 'https://images.unsplash.com/photo-1476275466078-4007374efbbe?auto=format&fit=crop&q=80&w=800',
    author: 'Michael Chen',
    date: '2024-03-10',
    category: 'Book Lists',
  },
  {
    title: 'How to Create the Perfect Reading Nook',
    excerpt: 'Transform any corner of your home into a cozy retreat perfect for diving into your favorite books.',
    image: 'https://images.unsplash.com/photo-1519682577862-22b62b24e493?auto=format&fit=crop&q=80&w=800',
    author: 'Emily Rodriguez',
    date: '2024-03-05',
    category: 'Lifestyle',
  },
  {
    title: 'The Rise of Independent Bookstores',
    excerpt: 'Despite digital competition, independent bookstores are making a comeback. Here\'s why.',
    image: 'https://images.unsplash.com/photo-1526243741027-444d633d7365?auto=format&fit=crop&q=80&w=800',
    author: 'David Wilson',
    date: '2024-03-01',
    category: 'Industry News',
  },
];

export function BlogPage() {
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Featured Post */}
      <article className="mb-16">
        <div className="relative aspect-[2/1] rounded-xl overflow-hidden mb-8">
          <img
            src={featuredPost.image}
            alt={featuredPost.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-0 left-0 p-8 text-white">
            <div className="flex items-center space-x-4 mb-4">
              <span className="bg-emerald-500 px-3 py-1 rounded-full text-sm">
                {featuredPost.category}
              </span>
              <div className="flex items-center space-x-2">
                <Calendar className="h-4 w-4" />
                <span>{new Date(featuredPost.date).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center space-x-2">
                <User className="h-4 w-4" />
                <span>{featuredPost.author}</span>
              </div>
            </div>
            <h1 className="text-4xl font-bold mb-4">{featuredPost.title}</h1>
            <p className="text-lg text-gray-200 mb-6">{featuredPost.excerpt}</p>
            <button className="inline-flex items-center space-x-2 text-emerald-400 hover:text-emerald-300">
              <span>Read More</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </article>

      {/* Recent Posts */}
      <section>
        <h2 className="text-3xl font-bold text-navy mb-8">Recent Posts</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {posts.map((post) => (
            <article key={post.title} className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="aspect-[3/2]">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
                  <span className="text-emerald-600">{post.category}</span>
                  <span>•</span>
                  <span>{new Date(post.date).toLocaleDateString()}</span>
                </div>
                <h3 className="text-xl font-bold text-navy mb-2">{post.title}</h3>
                <p className="text-gray-600 mb-4">{post.excerpt}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <User className="h-4 w-4" />
                    <span>{post.author}</span>
                  </div>
                  <button className="text-emerald-600 hover:text-emerald-700">
                    Read More →
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}