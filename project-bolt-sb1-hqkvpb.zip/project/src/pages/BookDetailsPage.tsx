import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { BookDetails } from '../types/book';
import { getBookDetails } from '../services/books';
import { Loader } from '../components/Loader';
import { ReviewStars } from '../components/ReviewStars';
import { Heart, Share2, BookOpen, ExternalLink, Award, Calendar, Book, Globe2, ShoppingCart } from 'lucide-react';

export function BookDetailsPage() {
  const { bookId } = useParams<{ bookId: string }>();
  const [book, setBook] = useState<BookDetails | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadBookDetails = async () => {
      if (!bookId) return;
      
      setIsLoading(true);
      setError(null);
      
      try {
        const details = await getBookDetails(bookId);
        setBook(details);
      } catch (err) {
        setError('Failed to load book details');
      } finally {
        setIsLoading(false);
      }
    };

    loadBookDetails();
  }, [bookId]);

  if (isLoading) return <Loader />;
  if (error) return <div className="text-red-500 text-center py-12">{error}</div>;
  if (!book) return <div className="text-center py-12">Book not found</div>;

  const googleBooksUrl = `https://books.google.com/books?id=${bookId}`;
  const amazonUrl = `https://www.amazon.com/s?k=${encodeURIComponent(`${book.title} ${book.authors[0]}`)}`;

  // Calculate discounted price (20% off retail)
  const retailPrice = book.price;
  const discountedPrice = (retailPrice * 0.8).toFixed(2);

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Breadcrumb */}
      <nav className="mb-8">
        <ol className="flex items-center space-x-2 text-sm text-gray-500">
          <li><a href="/" className="hover:text-emerald-600">Home</a></li>
          <li>/</li>
          <li><a href={`/category/${book.categories[0]?.toLowerCase()}`} className="hover:text-emerald-600">{book.categories[0]}</a></li>
          <li>/</li>
          <li className="text-gray-900">{book.title}</li>
        </ol>
      </nav>

      <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 p-8">
          {/* Left Column - Image */}
          <div className="space-y-6">
            <div className="aspect-[3/4] relative rounded-lg overflow-hidden shadow-2xl">
              <img
                src={book.coverUrl}
                alt={book.title}
                className="w-full h-full object-cover transform transition-transform duration-300 hover:scale-105"
              />
              {book.isUsed && (
                <div className="absolute top-4 right-4">
                  <span className="bg-gray-900/75 text-white px-3 py-1 rounded-full text-sm font-medium backdrop-blur-sm">
                    USED
                  </span>
                </div>
              )}
            </div>
            <div className="flex justify-center space-x-4">
              <button className="flex items-center space-x-2 px-6 py-3 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                <Heart className="h-5 w-5" />
                <span>Save</span>
              </button>
              <button className="flex items-center space-x-2 px-6 py-3 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                <Share2 className="h-5 w-5" />
                <span>Share</span>
              </button>
            </div>
          </div>

          {/* Right Column - Details */}
          <div className="space-y-8">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">{book.title}</h1>
              {book.subtitle && (
                <p className="text-xl text-gray-600 mb-4">{book.subtitle}</p>
              )}
              <p className="text-lg text-gray-600">
                by {book.authors.join(', ')}
              </p>
            </div>

            <div className="flex items-center space-x-4">
              <ReviewStars rating={book.rating} size={24} />
              <span className="text-gray-600">
                ({book.ratingsCount.toLocaleString()} ratings)
              </span>
            </div>

            <div className="bg-emerald-50 rounded-xl p-6 space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">List Price:</span>
                  <span className="text-xl line-through text-gray-500">${retailPrice.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Our Price:</span>
                  <span className="text-3xl font-bold text-emerald-600">${discountedPrice}</span>
                </div>
                <p className="text-sm text-emerald-700">You save ${(retailPrice - parseFloat(discountedPrice)).toFixed(2)} (20%)</p>
              </div>

              <div className="grid grid-cols-1 gap-4">
                <a
                  href={amazonUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center space-x-2 bg-orange-500 text-white py-4 px-6 rounded-lg hover:bg-orange-600 transition-colors"
                >
                  <ShoppingCart className="h-5 w-5" />
                  <span>View on Amazon</span>
                  <ExternalLink className="h-4 w-4" />
                </a>
                <a
                  href={googleBooksUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center space-x-2 bg-emerald-600 text-white py-4 px-6 rounded-lg hover:bg-emerald-700 transition-colors"
                >
                  <BookOpen className="h-5 w-5" />
                  <span>View on Google Books</span>
                  <ExternalLink className="h-4 w-4" />
                </a>
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-semibold">About this book</h2>
              <p className="text-gray-600 leading-relaxed">{book.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="flex items-start space-x-3">
                <Award className="h-5 w-5 text-emerald-600 mt-1" />
                <div>
                  <p className="font-medium">Publisher</p>
                  <p className="text-gray-600">{book.publisher}</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Calendar className="h-5 w-5 text-emerald-600 mt-1" />
                <div>
                  <p className="font-medium">Published Date</p>
                  <p className="text-gray-600">
                    {new Date(book.publishedDate).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Book className="h-5 w-5 text-emerald-600 mt-1" />
                <div>
                  <p className="font-medium">Pages</p>
                  <p className="text-gray-600">{book.pageCount}</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Globe2 className="h-5 w-5 text-emerald-600 mt-1" />
                <div>
                  <p className="font-medium">Language</p>
                  <p className="text-gray-600">{book.language.toUpperCase()}</p>
                </div>
              </div>
            </div>

            {book.categories.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {book.categories.map((category) => (
                  <a
                    key={category}
                    href={`/category/${category.toLowerCase()}`}
                    className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-gray-200 transition-colors"
                  >
                    {category}
                  </a>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}