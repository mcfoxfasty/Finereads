import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Search } from 'lucide-react';

const faqs = [
  {
    category: 'Ordering',
    questions: [
      {
        q: 'How do I place an order?',
        a: 'You can place an order by browsing our collection, adding items to your cart, and proceeding to checkout. You\'ll need to create an account or sign in to complete your purchase.',
      },
      {
        q: 'What payment methods do you accept?',
        a: 'We accept all major credit cards (Visa, MasterCard, American Express), PayPal, and various local payment methods depending on your location.',
      },
      {
        q: 'Can I modify or cancel my order?',
        a: 'Orders can be modified or cancelled within 1 hour of placement. Please contact our customer service team for assistance.',
      },
    ],
  },
  {
    category: 'Shipping',
    questions: [
      {
        q: 'How long does shipping take?',
        a: 'Domestic shipping typically takes 3-5 business days. International shipping can take 7-14 business days depending on the destination.',
      },
      {
        q: 'Do you ship internationally?',
        a: 'Yes, we ship to most countries worldwide. Shipping costs and delivery times vary by location.',
      },
      {
        q: 'Is shipping free?',
        a: 'We offer free shipping on orders over $35 within the continental United States. International shipping rates vary by location.',
      },
    ],
  },
  {
    category: 'Returns',
    questions: [
      {
        q: 'What is your return policy?',
        a: 'We accept returns within 30 days of delivery. Books must be in their original condition. Please contact us for a return authorization before sending any items back.',
      },
      {
        q: 'How do I return a book?',
        a: 'To return a book, contact our customer service team for a return authorization. Once approved, we\'ll provide shipping instructions and a return label.',
      },
      {
        q: 'Will I get a full refund?',
        a: 'Yes, you\'ll receive a full refund for the book price if it\'s returned in its original condition. Shipping costs are non-refundable unless the return is due to our error.',
      },
    ],
  },
];

export function FAQPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [openQuestions, setOpenQuestions] = useState<string[]>([]);

  const toggleQuestion = (question: string) => {
    setOpenQuestions((prev) =>
      prev.includes(question)
        ? prev.filter((q) => q !== question)
        : [...prev, question]
    );
  };

  const filteredFaqs = faqs.map((category) => ({
    ...category,
    questions: category.questions.filter(
      (q) =>
        q.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.a.toLowerCase().includes(searchQuery.toLowerCase())
    ),
  })).filter((category) => category.questions.length > 0);

  return (
    <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold text-navy mb-4">
          Frequently Asked Questions
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Find answers to common questions about our services
        </p>
        <div className="relative max-w-xl mx-auto">
          <input
            type="search"
            placeholder="Search FAQs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
          <Search className="absolute left-4 top-3.5 h-5 w-5 text-gray-400" />
        </div>
      </header>

      <div className="space-y-8">
        {filteredFaqs.map((category) => (
          <section key={category.category}>
            <h2 className="text-2xl font-bold text-navy mb-4">
              {category.category}
            </h2>
            <div className="space-y-4">
              {category.questions.map((item) => (
                <div
                  key={item.q}
                  className="bg-white rounded-lg shadow-sm overflow-hidden"
                >
                  <button
                    onClick={() => toggleQuestion(item.q)}
                    className="w-full text-left px-6 py-4 flex items-center justify-between hover:bg-gray-50"
                  >
                    <span className="font-medium text-gray-900">{item.q}</span>
                    {openQuestions.includes(item.q) ? (
                      <ChevronUp className="h-5 w-5 text-gray-500" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-gray-500" />
                    )}
                  </button>
                  {openQuestions.includes(item.q) && (
                    <div className="px-6 py-4 bg-gray-50">
                      <p className="text-gray-600">{item.a}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>
        ))}
      </div>

      {/* Contact Section */}
      <section className="mt-16 text-center">
        <h2 className="text-2xl font-bold text-navy mb-4">
          Still have questions?
        </h2>
        <p className="text-gray-600 mb-6">
          We're here to help. Contact our support team for assistance.
        </p>
        <button className="inline-flex items-center justify-center px-6 py-3 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors">
          Contact Support
        </button>
      </section>
    </main>
  );
}