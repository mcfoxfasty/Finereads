import { Book, BookDetails } from '../types/book';

const API_KEY = import.meta.env.VITE_GOOGLE_BOOKS_API_KEY;
const BASE_URL = 'https://www.googleapis.com/books/v1/volumes';

export async function searchBooksByCategory(
  category: string,
  maxResults: number = 10,
  orderBy: 'relevance' | 'newest' = 'relevance'
): Promise<Book[]> {
  try {
    if (!API_KEY) {
      throw new Error('Google Books API key is not configured');
    }

    const response = await fetch(
      `${BASE_URL}?q=subject:${encodeURIComponent(category)}&maxResults=${maxResults}&orderBy=${orderBy}&key=${API_KEY}`
    );

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();

    if (!data.items) {
      return [];
    }

    return data.items.map((item: any) => ({
      id: item.id,
      title: item.volumeInfo.title || 'Untitled',
      author: item.volumeInfo.authors?.[0] || 'Unknown Author',
      description: item.volumeInfo.description || 'No description available',
      coverUrl: item.volumeInfo.imageLinks?.thumbnail?.replace('http:', 'https:') || 'https://via.placeholder.com/128x192?text=No+Cover',
      rating: item.volumeInfo.averageRating || 4,
      reviewCount: item.volumeInfo.ratingsCount || 0,
      price: item.saleInfo?.listPrice?.amount || 19.99,
      categories: item.volumeInfo.categories || [category],
      publishedDate: item.volumeInfo.publishedDate || new Date().toISOString(),
      isUsed: true,
      reviews: []
    }));
  } catch (error) {
    console.error('Error fetching books:', error);
    throw error;
  }
}

export async function getBookDetails(bookId: string): Promise<BookDetails> {
  try {
    if (!API_KEY) {
      throw new Error('Google Books API key is not configured');
    }

    const response = await fetch(
      `${BASE_URL}/${bookId}?key=${API_KEY}`
    );

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const item = await response.json();
    
    return {
      id: item.id,
      title: item.volumeInfo.title || 'Untitled',
      subtitle: item.volumeInfo.subtitle || '',
      authors: item.volumeInfo.authors || ['Unknown Author'],
      description: item.volumeInfo.description || 'No description available',
      coverUrl: item.volumeInfo.imageLinks?.thumbnail?.replace('http:', 'https:') || 'https://via.placeholder.com/128x192?text=No+Cover',
      rating: item.volumeInfo.averageRating || 4,
      ratingsCount: item.volumeInfo.ratingsCount || 0,
      reviewCount: item.volumeInfo.ratingsCount || 0,
      price: item.saleInfo?.listPrice?.amount || 19.99,
      categories: item.volumeInfo.categories || [],
      pageCount: item.volumeInfo.pageCount || 0,
      publisher: item.volumeInfo.publisher || 'Unknown Publisher',
      publishedDate: item.volumeInfo.publishedDate || '',
      isbn: item.volumeInfo.industryIdentifiers?.[0]?.identifier || '',
      language: item.volumeInfo.language || 'en',
      isUsed: true,
      reviews: []
    };
  } catch (error) {
    console.error('Error fetching book details:', error);
    throw error;
  }
}

export async function searchBooks(
  query: string,
  category?: string,
  sortBy: 'relevance' | 'newest' = 'relevance',
  startIndex: number = 0,
  maxResults: number = 10
) {
  try {
    if (!API_KEY) {
      throw new Error('Google Books API key is not configured');
    }

    let q = query;
    if (category) {
      q += `+subject:${category}`;
    }

    const response = await fetch(
      `${BASE_URL}?q=${encodeURIComponent(q)}&startIndex=${startIndex}&maxResults=${maxResults}&orderBy=${sortBy}&key=${API_KEY}`
    );

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();

    const books = data.items ? data.items.map((item: any) => ({
      id: item.id,
      title: item.volumeInfo.title || 'Untitled',
      author: item.volumeInfo.authors?.[0] || 'Unknown Author',
      description: item.volumeInfo.description || 'No description available',
      coverUrl: item.volumeInfo.imageLinks?.thumbnail?.replace('http:', 'https:') || 'https://via.placeholder.com/128x192?text=No+Cover',
      rating: item.volumeInfo.averageRating || 4,
      reviewCount: item.volumeInfo.ratingsCount || 0,
      price: item.saleInfo?.listPrice?.amount || 19.99,
      categories: item.volumeInfo.categories || [],
      publishedDate: item.volumeInfo.publishedDate || new Date().toISOString(),
      isUsed: true,
      reviews: []
    })) : [];

    return {
      books,
      totalItems: data.totalItems || 0
    };
  } catch (error) {
    console.error('Error searching books:', error);
    throw error;
  }
}

export async function getEditorsPicks(): Promise<Book[]> {
  const editorsPicks = [
    {
      query: 'intitle:"Project Hail Mary"+inauthor:"Andy Weir"',
      description: 'A lone astronaut must save humanity from extinction in this thrilling sci-fi adventure'
    },
    {
      query: 'intitle:"Tomorrow, and Tomorrow, and Tomorrow"+inauthor:"Gabrielle Zevin"',
      description: 'A modern masterpiece about love, friendship, and the power of games'
    },
    {
      query: 'intitle:"Demon Copperhead"+inauthor:"Barbara Kingsolver"',
      description: 'A powerful coming-of-age novel set in Appalachia'
    },
    {
      query: 'intitle:"The Seven Husbands of Evelyn Hugo"+inauthor:"Taylor Jenkins Reid"',
      description: 'A mesmerizing novel about old Hollywood and forbidden love'
    },
    {
      query: 'intitle:"The Midnight Library"+inauthor:"Matt Haig"',
      description: 'Between life and death there is a library that contains infinite possibilities'
    }
  ];

  try {
    const booksPromises = editorsPicks.map(async ({ query }) => {
      const { books } = await searchBooks(query, undefined, 'relevance', 0, 1);
      return books[0];
    });

    const books = await Promise.all(booksPromises);
    return books.filter((book): book is Book => book !== undefined);
  } catch (error) {
    console.error('Error fetching editor\'s picks:', error);
    return [];
  }
}