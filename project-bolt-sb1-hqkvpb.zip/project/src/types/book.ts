export interface Book {
  id: string;
  title: string;
  author: string;
  description: string;
  coverUrl: string;
  rating: number;
  reviewCount: number;
  price: number;
  categories: string[];
  publishedDate: string;
  isUsed: boolean;
  reviews: Review[];
  edition?: string;
  condition?: BookCondition;
  rarity?: RarityLevel;
  readingStatus?: ReadingStatus;
  readingProgress?: number;
  collectionTags?: string[];
  notes?: string;
}

export interface BookDetails extends Omit<Book, 'author'> {
  subtitle: string;
  authors: string[];
  ratingsCount: number;
  pageCount: number;
  publisher: string;
  isbn: string;
  language: string;
  binding?: string;
  printRun?: string;
  specialFeatures?: string[];
}

export type BookCondition = 'New' | 'Fine' | 'Very Good' | 'Good' | 'Fair' | 'Poor';

export type RarityLevel = 'Common' | 'Uncommon' | 'Rare' | 'Very Rare' | 'Unique';

export type ReadingStatus = 'To Read' | 'Reading' | 'Completed' | 'DNF';

export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export type SortOption = 'relevance' | 'newest' | 'rarity' | 'condition';

export interface BookFilters {
  category?: string;
  sortBy: SortOption;
  searchQuery: string;
  condition?: BookCondition;
  rarity?: RarityLevel;
  readingStatus?: ReadingStatus;
}

export interface CategoryCount {
  name: string;
  count: number;
}

export interface BookCategory {
  name: string;
  count: number;
  description: string;
}